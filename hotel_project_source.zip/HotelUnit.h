#ifndef HOTEL_UNIT_H
#define HOTEL_UNIT_H

#include <string>
#include <iostream>
using namespace std;

/*
 * HotelUnit
 * ---------
 * Abstract base class sitting at the TOP of the inheritance diamond.
 * Both Room and Service inherit from HotelUnit VIRTUALLY, so that any
 * class which later combines a Room and a Service (see DeluxeRoomService
 * in Services.h) ends up with only ONE copy of HotelUnit's data members
 * instead of two duplicate copies. This is the classic diamond problem,
 * solved here using virtual base classes.
 *
 * It is an abstract class because it declares pure virtual functions
 * (getCost() and display()) — it can never be instantiated directly,
 * only through a derived, concrete class, and is always accessed through
 * a base class pointer/reference for runtime polymorphism.
 */
class HotelUnit {
protected:
    int unitId;
    string unitName;

public:
    HotelUnit() : unitId(0), unitName("Unnamed") {}
    HotelUnit(int id, string name) : unitId(id), unitName(name) {}

    // Pure virtual functions -> makes HotelUnit an ABSTRACT class
    virtual double getCost() const = 0;
    virtual void display() const = 0;

    int getId() const { return unitId; }
    string getName() const { return unitName; }

    virtual ~HotelUnit() {
        // virtual destructor is essential here because objects of derived
        // classes are always deleted through a HotelUnit* / Room* pointer
    }
};

#endif
