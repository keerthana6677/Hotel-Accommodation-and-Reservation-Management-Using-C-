#ifndef SERVICES_H
#define SERVICES_H

#include "HotelUnit.h"
#include "Rooms.h"
#include <string>
#include <iostream>
using namespace std;

/*
 * Service
 * -------
 * Also inherits VIRTUALLY from HotelUnit, exactly like Room does.
 * This is what sets up the diamond:
 *
 *                 HotelUnit
 *                /         \
 *            Room           Service
 *                \         /
 *            DeluxeRoomService
 *
 * Because both Room and Service inherit HotelUnit as `virtual`,
 * DeluxeRoomService (below) contains exactly ONE shared HotelUnit
 * sub-object instead of two ambiguous copies -- this is the required
 * demonstration of virtual base classes preventing duplication.
 */
class Service : public virtual HotelUnit {
protected:
    double serviceCharge;

public:
    Service() : serviceCharge(0) {}
    Service(int id, string name, double charge)
        : HotelUnit(id, name), serviceCharge(charge) {}

    virtual string getServiceCategory() const = 0;  // pure virtual -> abstract
};

/* ---------------- Concrete services (single inheritance from Service) ---------------- */

class FoodService : public Service {
public:
    FoodService(int id, double charge) : HotelUnit(id, "Food Service"), Service(id, "Food Service", charge) {}
    double getCost() const override { return serviceCharge; }
    string getServiceCategory() const override { return "Food & Dining"; }
    void display() const override {
        cout << "Service: Food Service | Charge: Rs." << serviceCharge << endl;
    }
};

class LaundryService : public Service {
public:
    LaundryService(int id, double charge) : HotelUnit(id, "Laundry Service"), Service(id, "Laundry Service", charge) {}
    double getCost() const override { return serviceCharge; }
    string getServiceCategory() const override { return "Housekeeping"; }
    void display() const override {
        cout << "Service: Laundry Service | Charge: Rs." << serviceCharge << endl;
    }
};

class SpaService : public Service {
public:
    SpaService(int id, double charge) : HotelUnit(id, "Spa Service"), Service(id, "Spa Service", charge) {}
    double getCost() const override { return serviceCharge; }
    string getServiceCategory() const override { return "Wellness"; }
    void display() const override {
        cout << "Service: Spa Service | Charge: Rs." << serviceCharge << endl;
    }
};

/*
 * DeluxeRoomService
 * -----------------
 * MULTIPLE INHERITANCE: inherits from both Suite (a Room) and a Service,
 * combining a premium room with a bundled service package (e.g. a suite
 * that already includes complimentary food service) into one billable
 * unit. Because Room and Service both used `virtual` inheritance from
 * HotelUnit, this class has one unambiguous HotelUnit base -- calling
 * getId()/getName() here does NOT produce a "which HotelUnit?" ambiguity
 * error, which is exactly the diamond problem virtual inheritance fixes.
 *
 * It overrides getCost()/display() itself (runtime polymorphism) to
 * combine the room rate with the service charge.
 */
class DeluxeRoomService : public Suite, public FoodService {
public:
    DeluxeRoomService(int id, string roomNo, int fl, double roomRate, double serviceCharge)
        : HotelUnit(id, "Deluxe Suite + Food Package"),
          Suite(id, roomNo, fl, roomRate),
          FoodService(id, serviceCharge) {}

    double getCost() const override {
        return Suite::getCost() + FoodService::getCost();
    }

    void display() const override {
        cout << "[" << roomNumber << "] Deluxe Suite + Food Package | Floor: " << floor
             << " | Capacity: " << capacity
             << " | Total Rate/Night: Rs." << getCost()
             << " | " << (available ? "Available" : "Occupied") << endl;
    }
};

#endif
