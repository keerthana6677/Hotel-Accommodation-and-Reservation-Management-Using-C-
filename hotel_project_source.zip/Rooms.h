#ifndef ROOMS_H
#define ROOMS_H

#include "HotelUnit.h"
#include <string>
#include <iostream>
using namespace std;

/*
 * Room
 * ----
 * Room inherits VIRTUALLY from HotelUnit. It is itself an abstract class
 * (adds another pure virtual function, getRoomType()), so the hierarchy
 * has TWO levels of abstraction: HotelUnit (generic) -> Room (room-
 * specific). This models single inheritance combined with a virtual base.
 *
 * Common data (roomNumber, floor, capacity, isAvailable) lives here once,
 * so SingleRoom / DoubleRoom / Suite do not repeat it (avoids duplication).
 */
class Room : public virtual HotelUnit {
protected:
    string roomNumber;
    int floor;
    int capacity;
    bool available;

public:
    Room() : roomNumber("NA"), floor(0), capacity(0), available(true) {}

    Room(int id, string name, string roomNo, int fl, int cap)
        : HotelUnit(id, name), roomNumber(roomNo), floor(fl), capacity(cap), available(true) {}

    virtual string getRoomType() const = 0;   // pure virtual -> Room stays abstract

    string getRoomNumber() const { return roomNumber; }
    bool isAvailable() const { return available; }
    void setAvailable(bool status) { available = status; }
    int getCapacity() const { return capacity; }
};

/* ---------------- Concrete room types (single inheritance from Room) ---------------- */

class SingleRoom : public Room {
    double baseRate;
public:
    SingleRoom(int id, string roomNo, int fl, double rate)
        : HotelUnit(id, "Single Room"), Room(id, "Single Room", roomNo, fl, 1), baseRate(rate) {}

    double getCost() const override { return baseRate; }
    string getRoomType() const override { return "Single Room"; }

    void display() const override {
        cout << "[" << roomNumber << "] Single Room | Floor: " << floor
             << " | Capacity: " << capacity
             << " | Rate/Night: Rs." << baseRate
             << " | " << (available ? "Available" : "Occupied") << endl;
    }
};

class DoubleRoom : public Room {
    double baseRate;
public:
    DoubleRoom(int id, string roomNo, int fl, double rate)
        : HotelUnit(id, "Double Room"), Room(id, "Double Room", roomNo, fl, 2), baseRate(rate) {}

    double getCost() const override { return baseRate; }
    string getRoomType() const override { return "Double Room"; }

    void display() const override {
        cout << "[" << roomNumber << "] Double Room | Floor: " << floor
             << " | Capacity: " << capacity
             << " | Rate/Night: Rs." << baseRate
             << " | " << (available ? "Available" : "Occupied") << endl;
    }
};

class Suite : public Room {
    double baseRate;
public:
    Suite(int id, string roomNo, int fl, double rate)
        : HotelUnit(id, "Suite"), Room(id, "Suite", roomNo, fl, 4), baseRate(rate) {}

    double getCost() const override { return baseRate; }
    string getRoomType() const override { return "Suite"; }

    void display() const override {
        cout << "[" << roomNumber << "] Suite | Floor: " << floor
             << " | Capacity: " << capacity
             << " | Rate/Night: Rs." << baseRate
             << " | " << (available ? "Available" : "Occupied") << endl;
    }
};

#endif
