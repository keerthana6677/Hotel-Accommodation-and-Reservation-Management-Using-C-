#ifndef RESERVATION_H
#define RESERVATION_H

#include "Guest.h"
#include "Rooms.h"
#include "Services.h"
#include <vector>
#include <string>
#include <iostream>
using namespace std;

/*
 * Reservation
 * -----------
 * Holds a Room* (base-class pointer) so that whichever concrete room
 * type (SingleRoom / DoubleRoom / Suite / DeluxeRoomService) was booked,
 * the reservation code calls room->getCost(), room->display() etc.
 * through the SAME interface -- this is RUNTIME POLYMORPHISM in action.
 * The actual function that executes is resolved at run time based on
 * the real object type, via the virtual functions declared in HotelUnit.
 */
class Reservation {
    int reservationId;
    Guest guest;
    Room* room;                 // base class pointer -> polymorphism
    vector<Service*> extraServices;
    int nights;
    bool active;

public:
    Reservation(int id, Guest g, Room* r, int nightsStayed)
        : reservationId(id), guest(g), room(r), nights(nightsStayed), active(true) {}

    void addService(Service* s) { extraServices.push_back(s); }

    int getId() const { return reservationId; }
    Room* getRoom() const { return room; }
    Guest getGuest() const { return guest; }
    bool isActive() const { return active; }
    void cancel() {
        active = false;
        room->setAvailable(true);
    }

    double calculateBill() const {
        double total = room->getCost() * nights;      // polymorphic call
        for (Service* s : extraServices)
            total += s->getCost();                     // polymorphic call
        return total;
    }

    void showDetails() const {
        cout << "\n----- Reservation #" << reservationId << (active ? "" : " (CANCELLED)") << " -----" << endl;
        guest.display();
        cout << "Room Type : " << room->getRoomType() << endl;
        room->display();                                // polymorphic call
        cout << "Nights Stayed: " << nights << endl;
        if (!extraServices.empty()) {
            cout << "Additional Services:" << endl;
            for (Service* s : extraServices)
                cout << "   - " << s->getServiceCategory() << " (Rs." << s->getCost() << ")" << endl;
        }
        cout << "TOTAL BILL: Rs." << calculateBill() << endl;
        cout << "----------------------------------------" << endl;
    }
};

#endif
