# Hotel Accommodation and Reservation Management System (C++)

A menu-driven, object-oriented C++ console application for managing hotel
rooms, guests, reservations, and services.

## Build & Run

```bash
g++ -std=c++17 -Wall -o hotel main.cpp
./hotel
```

## Files

| File | Purpose |
|---|---|
| `HotelUnit.h` | Abstract root class (top of the inheritance diamond) |
| `Rooms.h` | `Room` (abstract) + `SingleRoom`, `DoubleRoom`, `Suite` |
| `Services.h` | `Service` (abstract) + `FoodService`, `LaundryService`, `SpaService`, and `DeluxeRoomService` (multiple + virtual inheritance) |
| `Guest.h` | Guest data class |
| `Reservation.h` | Links a Guest to a Room, computes the bill |
| `main.cpp` | `HotelSystem` menu-driven controller + `main()` |

## OOP concepts demonstrated

- **Abstraction** – `HotelUnit`, `Room`, `Service` are abstract classes (pure virtual functions)
- **Encapsulation** – all data members are `private`/`protected`
- **Single inheritance** – `SingleRoom`/`DoubleRoom`/`Suite` from `Room`; `FoodService`/`LaundryService`/`SpaService` from `Service`
- **Multiple inheritance** – `DeluxeRoomService` inherits from both `Suite` and `FoodService`
- **Virtual base classes** – `Room` and `Service` both inherit `HotelUnit` virtually, so `DeluxeRoomService` (which inherits both `Room` and `Service` paths) has exactly one `HotelUnit` sub-object — the classic diamond problem, solved
- **Runtime polymorphism** – `Room*`/`Service*` base pointers, virtual functions (`getCost()`, `display()`, `getRoomType()`) resolved at run time

## Sample menu

```
1. Register Guest
2. Check Room Availability
3. Make Reservation
4. Cancel Reservation
5. Generate Bill / Reservation Details
6. List All Reservations
7. Exit
```
