#ifndef GUEST_H
#define GUEST_H

#include <string>
#include <iostream>
using namespace std;

class Guest {
    int guestId;
    string name;
    string phone;

public:
    Guest() : guestId(0), name(""), phone("") {}
    Guest(int id, string n, string ph) : guestId(id), name(n), phone(ph) {}

    int getId() const { return guestId; }
    string getName() const { return name; }
    string getPhone() const { return phone; }

    void display() const {
        cout << "Guest ID: " << guestId << " | Name: " << name << " | Phone: " << phone << endl;
    }
};

#endif
