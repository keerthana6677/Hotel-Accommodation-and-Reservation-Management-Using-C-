/*
 * Hotel Accommodation and Reservation Management System
 * -------------------------------------------------------
 * Menu-driven, object-oriented C++ application.
 *
 * Demonstrates:
 *  - Abstraction        : HotelUnit, Room, Service are abstract classes
 *  - Encapsulation       : private/protected data with public interfaces
 *  - Single inheritance  : SingleRoom/DoubleRoom/Suite <- Room ; FoodService etc. <- Service
 *  - Multiple inheritance: DeluxeRoomService <- Suite + FoodService
 *  - Virtual base class  : Room and Service both inherit HotelUnit virtually,
 *                          so DeluxeRoomService (which inherits both) has only
 *                          ONE HotelUnit sub-object -> classic diamond problem, solved.
 *  - Runtime polymorphism: Room and HotelUnit pointers, virtual functions,
 *                          resolved at run time (getCost(), display(), getRoomType()).
 */

#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include "Guest.h"
#include "Rooms.h"
#include "Services.h"
#include "Reservation.h"
using namespace std;

class HotelSystem {
    vector<Room*> rooms;              // polymorphic collection of rooms
    vector<Guest> guests;
    vector<Reservation*> reservations;
    int nextGuestId, nextReservationId;

public:
    HotelSystem() : nextGuestId(1), nextReservationId(1) {}

    void seedRooms() {
        rooms.push_back(new SingleRoom(1, "S101", 1, 1500));
        rooms.push_back(new SingleRoom(2, "S102", 1, 1500));
        rooms.push_back(new DoubleRoom(3, "D201", 2, 2500));
        rooms.push_back(new DoubleRoom(4, "D202", 2, 2500));
        rooms.push_back(new Suite(5, "SU301", 3, 5000));
        rooms.push_back(new DeluxeRoomService(6, "DX401", 4, 7000, 800));
    }

    ~HotelSystem() {
        for (auto r : rooms) delete r;
        for (auto res : reservations) delete res;
    }

    void registerGuest() {
        string name, phone;
        cout << "Enter Guest Name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter Phone Number: ";
        getline(cin, phone);
        guests.push_back(Guest(nextGuestId++, name, phone));
        cout << "Guest registered successfully. Guest ID: " << guests.back().getId() << endl;
    }

    void checkAvailability() {
        cout << "\n--- Room Availability ---\n";
        for (Room* r : rooms) {
            if (r->isAvailable())
                r->display();          // polymorphic call - correct display() runs per room type
        }
    }

    Guest* findGuest(int id) {
        for (auto &g : guests)
            if (g.getId() == id) return &g;
        return nullptr;
    }

    void makeReservation() {
        int guestId;
        cout << "Enter Guest ID (0 to register new guest): ";
        cin >> guestId;
        if (guestId == 0) {
            registerGuest();
            guestId = guests.back().getId();
        }
        Guest* g = findGuest(guestId);
        if (!g) { cout << "Guest not found.\n"; return; }

        checkAvailability();
        string roomNo;
        cout << "Enter Room Number to book: ";
        cin >> roomNo;

        Room* selected = nullptr;
        for (Room* r : rooms)
            if (r->getRoomNumber() == roomNo && r->isAvailable()) { selected = r; break; }

        if (!selected) { cout << "Room not available.\n"; return; }

        int nights;
        cout << "Enter number of nights: ";
        cin >> nights;

        Reservation* res = new Reservation(nextReservationId++, *g, selected, nights);
        selected->setAvailable(false);

        char addSvc;
        cout << "Add extra service? (y/n): ";
        cin >> addSvc;
        if (addSvc == 'y' || addSvc == 'Y') {
            int choice;
            cout << "1. Laundry Service (Rs.300)\n2. Spa Service (Rs.1200)\nChoice: ";
            cin >> choice;
            if (choice == 1) res->addService(new LaundryService(100, 300));
            else if (choice == 2) res->addService(new SpaService(101, 1200));
        }

        reservations.push_back(res);
        cout << "Reservation successful! Reservation ID: " << res->getId() << endl;
        res->showDetails();
    }

    void cancelReservation() {
        int resId;
        cout << "Enter Reservation ID to cancel: ";
        cin >> resId;
        for (auto res : reservations) {
            if (res->getId() == resId && res->isActive()) {
                res->cancel();
                cout << "Reservation #" << resId << " cancelled. Room is now available.\n";
                return;
            }
        }
        cout << "Active reservation not found.\n";
    }

    void generateBill() {
        int resId;
        cout << "Enter Reservation ID: ";
        cin >> resId;
        for (auto res : reservations) {
            if (res->getId() == resId) {
                res->showDetails();
                return;
            }
        }
        cout << "Reservation not found.\n";
    }

    void listAllReservations() {
        cout << "\n--- All Reservations ---\n";
        if (reservations.empty()) { cout << "No reservations yet.\n"; return; }
        for (auto res : reservations)
            res->showDetails();
    }

    void menu() {
        int choice;
        do {
            cout << "\n========= HOTEL RESERVATION MANAGEMENT SYSTEM =========\n";
            cout << "1. Register Guest\n";
            cout << "2. Check Room Availability\n";
            cout << "3. Make Reservation\n";
            cout << "4. Cancel Reservation\n";
            cout << "5. Generate Bill / Reservation Details\n";
            cout << "6. List All Reservations\n";
            cout << "7. Exit\n";
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) {
                case 1: registerGuest(); break;
                case 2: checkAvailability(); break;
                case 3: makeReservation(); break;
                case 4: cancelReservation(); break;
                case 5: generateBill(); break;
                case 6: listAllReservations(); break;
                case 7: cout << "Thank you for using the Hotel Reservation System!\n"; break;
                default: cout << "Invalid choice. Try again.\n";
            }
        } while (choice != 7);
    }
};

int main() {
    HotelSystem hotel;
    hotel.seedRooms();
    hotel.menu();
    return 0;
}
